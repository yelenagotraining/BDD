"use strict";
var classes_1 = require('./classes');
classes_1.UniversityLibrarian.prototype.hostSeminar = function (topic) {
    console.log('Hosting a seminar on ' + topic);
};
