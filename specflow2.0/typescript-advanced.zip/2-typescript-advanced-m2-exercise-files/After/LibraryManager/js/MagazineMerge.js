"use strict";
Magazine.prototype.editor;
