"use strict";
var classes_1 = require("./classes");
classes_1.UniversityLibrarian.prototype.shelveIt = function (b) {
};
// import { Researcher } from './classes';
// declare module './classes' {
//     interface Researcher {
//         //specialty: string;
//         doResearch(): void;
//     }
// }
// Researcher.prototype.doResearch = function() {
//     // do something
// }
